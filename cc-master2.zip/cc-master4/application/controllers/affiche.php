<?php 
class Affiche extends CI_Controller{
    public function index (){

        $this->load->view('affiche');

    }
   
}