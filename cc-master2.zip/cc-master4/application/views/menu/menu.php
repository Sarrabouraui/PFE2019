<?php $GLOBALS['layoutid'] = 0 ?>

<div class='sidebar'style="background-color:white;">
	<div class='title'style="background-color:#17A2B8;">
		Menu
	</div>
	<ul>
		<li>
			<a href="<?php echo base_url(); ?>dash/index/dash">
				<i class="fa fa-home fa-2x"></i>
				<span style="font-size:14px;" class="nav-text">
                            Dashboard
                        </span>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>displays/index/dis">
				<i class="fa fa-laptop fa-2x"></i>
				<span style="font-size:14px;"class="nav-text">
                            Displays
                        </span>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>welcome/index/picture_list">
				<i class="fa fa-folder-open fa-2x"></i>
				<span style="font-size:14px;"class="nav-text">
                            Media
                        </span>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>layout/index/lay">
				<i class="fa fa-list fa-2x"></i>
				<span style="font-size:14px;"class="nav-text">
                            Layouts
                        </span>
			</a>
	
		<li>
			<a href="<?php echo base_url(); ?>calendar/index/calendar">
				<i class="fa fa-table fa-2x"></i>
				<span style="font-size:14px;"class="nav-text">
                            Planner
                        </span>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-info fa-2x"></i>
				<span style="font-size:14px;" class="nav-text">
                            Help
                        </span>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-power-off fa-2x"></i>
				<span style="font-size:14px;"class="nav-text">
                            Logout
                        </span>
			</a>
		</li>
	</ul>
</div>
