<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PFE</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/login.css">
	<script type='text/javascript' src="<?php echo base_url(); ?>assets/javascript/login.js"></script>


</head>
<body>
<form class="box" action="" method="post">
	<h1>login</h1>
	<input type="text" name="username" id="username" placeholder="Username">
	<input type="password" name="password" id="password" placeholder="Password">
	<input type="submit" name="login" value="login">


</form>

<img class="img" src="<?php echo base_url('assets/image/a.jpg'); ?>"/>


</body>
</html>
