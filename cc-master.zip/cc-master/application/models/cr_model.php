<?php

class Cr_model extends CI_Model
{

//fetch all pictures from db
	function get_all_pics()
	{
		$all_pics = $this->db->get('pictures');
		return $all_pics->result();
	}

	public function add($data/*,$pf*/)
	{
		/*$this->db->where('pic_id', $data);
        $this->db->select('pic_file');
       // $this->db->from('pictures');

        $q = $this->db->get('pictures');
        */
		//$q = $this->db->get_where('pictures', array('pic_id' => $data));
		//$q = $this->db->query("INSERT INTO lay_cont(pfile) SELECT pic_file FROM pictures p , lay_cont l WHERE l.pic = p.pic_id ; ");

		/* $this->db->query("SELECT pic_file FROM pictures WHERE pic_id = '".$data."' ;");
         $d = $this->db->get();*/

		$d = $this->db->select("pic_file")->where("pic_id =", $data)->get("pictures");

		//$q = $this->db->query("INSERT INTO lay_cont(pfile) VALUE('ab') ; ");

		//$q = $this->input->post('img1');

		$this->db->select_max('lay_id', 'max');
		$query = $this->db->get('layouts');
		$max = $query->row()->max;

		$insert_data['lay'] = $max;
		$insert_data['pic'] = $data;
		$insert_data['pfile'] = $d;

		$this->db->insert('lay_cont', $insert_data);
		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}

}

