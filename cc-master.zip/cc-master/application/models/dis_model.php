<?php
defined ('BASEPATH') OR exit ('No direct script access allowed');
class Dis_model extends CI_Model{
    public function showAllDisplay(){
       $query = $this->db->get('displays');
       if ($query->num_rows()>0){
        return $query->result();
       }else{
           return false;
       }
    }
    public function addDisplay(){
        $field = array(
            'mac'=>$this->input->post('txtMacAddress'),
            'ip'=>$this->input->post('txtIpAddress')

        );
        $this->db->insert('displays', $field);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
public function editDisplay(){
    $id = $this->input->get('id');
    $this->db->where('id', $id);
    $query = $this->db->get('displays');
    if($query->num_rows() >0){
        return $query->row();
    }else{
        return false;
    }
}
public function updateDisplay(){
    $id= $this->input->post('txtId');
    $field = array(
        'mac'=> $this->input->post('txtMacAddress'),
        'ip'=> $this->input->post('txtIpAddress'),

    );
    $this->db->where('id', $id);
    $this->db->update('displays', $field);
    if($this->db->affected_rows() > 0){
        return true;
    }else{
        return false;
    }
}
function deleteDisplay(){
    $id = $this->input->get('id');
    $this->db->where('id', $id);
    $this->db->delete('displays');
    if($this->db->affected_rows() > 0){
        return true;
    }else{
        return false;
    }
}
}