<?php
 
class Lay_model extends CI_Model{

//fetch all pictures from db
function get_all_pics(){
    $all_pics = $this->db->get('pictures');
    return $all_pics->result();
    }
    public function showAllLayout(){
       $query = $this->db->get('layouts');
       if ($query->num_rows()>0){
        return $query->result();
       }else{
           return false;
       }
    }

    
    public function addLayout(){
        $field = array(
            'lay_title'=>$this->input->post('txtName'),
            'lay_date'=>$this->input->post('txtDate'),
            'lay_from'=>$this->input->post('txtFrom'),
            'lay_to'=>$this->input->post('txtTo')
         );
        $this->db->insert('layouts', $field);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }
    
public function editLayout(){
    $lay_id = $this->input->get('lay_id');
    $this->db->where('lay_id', $lay_id);
    $query = $this->db->get('layouts');
    if($query->num_rows() >0){
        return $query->row();
    }else{
        return false;
    }
}
public function updateLayout(){
    $lay_id= $this->input->post('txtId');
    $field = array(
        'lay_title'=> $this->input->post('txtName'),
        'lay_date'=> $this->input->post('txtDate'),
        'lay_from'=> $this->input->post('txtFrom'),
        'lay_to'=> $this->input->post('txtTo'),
    );
    $this->db->where('lay_id', $lay_id);
    $this->db->update('layouts', $field);
    if($this->db->affected_rows() > 0){
        return true;
    }else{
        return false;
    }
}
function deleteLayout(){
    $lay_id = $this->input->get('lay_id');
    $this->db->where('lay_id', $lay_id);
    $this->db->delete('layouts');
    if($this->db->affected_rows() > 0){
        return true;
    }else{
        return false;
    }
}

public function slide()
{
    $lay_id = $this->input->get('lay_id');
    
        /*$query = $this->db->query("SELECT P.pic_file FROM pictures P, lay_cont LA, layouts L 
        WHERE LA.pic = P.pic_id AND LA.lay = $lay_id ;");*/
       $this->db->select('pic_file');
        $this->db->from('pictures');
        $this->db->join('lay_cont','lay_cont.pic = pictures.pic_id ');
        //$this->db->where('lay_cont.lay', $lay_id);
        //$this->db->join("l.lay = '$lay_id'");
         $query = $this->db->get();
        //return $query->result();        
           
}
public function event()
{
$field = array(
    'title'=>$this->input->post('txtName'),
    'date'=>$this->input->post('txtDate'),
    'start'=>$this->input->post('txtFrom'),
    'end'=>$this->input->post('txtTo')
 );
$this->db->insert('events', $field);
}
}
