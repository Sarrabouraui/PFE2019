<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/calend.css">
</head>
<body>
<div>
	<h4>
		<a style="text-decoration:none;" href="https://www.zeitverschiebung.net/fr/timezone/africa--tunis">
			<span>Heure actuelle</span>
			<br/>Africa/Tunis</a>
	</h4>
	<iframe src="https://www.zeitverschiebung.net/clock-widget-iframe-v2?language=fr&size=small&timezone=Africa%2FTunis"
			frameborder="0" ;
			seamless>
	</iframe>
</div>
</body>
