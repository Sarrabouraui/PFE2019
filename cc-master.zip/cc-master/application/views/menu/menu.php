<div class='sidebar'>
	<div class='title'>
		Menu
	</div>
	<ul>
		<li>
			<a href="#">
				<i class="fa fa-home fa-2x"></i>
				<span class="nav-text">
                            Dashboard
                        </span>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>displays/index/dis">
				<i class="fa fa-laptop fa-2x"></i>
				<span class="nav-text">
                            Displays
                        </span>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>welcome/index/picture_list">
				<i class="fa fa-folder-open fa-2x"></i>
				<span class="nav-text">
                            Media
                        </span>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url(); ?>layout/index/lay">
				<i class="fa fa-list fa-2x"></i>
				<span class="nav-text">
                            Layouts
                        </span>
			</a>
		<li>
			<a href="#">
				<i class="fa fa-bar-chart-o fa-2x"></i>
				<span class="nav-text">
                            Graphs and Statistics
                        </span>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-table fa-2x"></i>
				<span class="nav-text">
                            Planner
                        </span>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-info fa-2x"></i>
				<span class="nav-text">
                            Help
                        </span>
			</a>
		</li>
		<li>
			<a href="#">
				<i class="fa fa-power-off fa-2x"></i>
				<span class="nav-text">
                            Logout
                        </span>
			</a>
		</li>
	</ul>
</div>
