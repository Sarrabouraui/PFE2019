<?php $this->load->view('header/header') ?>

<body>


<div class="wrapper">
	<?php $this->load->view('menu/menu') ?>


	<div class="content isOpen">

		<header>

			<nav class="nav">

			</nav>
		</header>

	</div>
</div>


</body>
